#used resizer
from random import randint
def barrand6():
    return '_'+str( randint(1,1000000))
